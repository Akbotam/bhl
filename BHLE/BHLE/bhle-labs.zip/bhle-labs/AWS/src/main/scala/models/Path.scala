package models

case class Path (path: String)