package models

case class Message (msg: String)
