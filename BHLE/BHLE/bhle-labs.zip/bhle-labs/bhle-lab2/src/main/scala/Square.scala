case class Square(lenght: Double) extends Rectangular {
    def height = lenght
    def name = "square"
}
