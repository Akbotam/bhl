case class Water (size: Int, source: Source, carbonated: Boolean){

}
