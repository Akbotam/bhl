object Draw {
    def apply (sh: Shape): String = {
        sh.toString
    }
}
