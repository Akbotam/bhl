case class Rectangle(lenght: Double, height: Double) extends Rectangular {
    def name = "rectangle"
}
